W(3,3) / W33 structural audit bundle

This bundle reconstructs the classical symplectic generalized quadrangle W(3,3) as:
- Points = PG(3,3) points (40 projective points).
- GQ lines = totally isotropic projective lines w.r.t. a symplectic form (40 such lines).

It then computes:
- Point collinearity graph (points adjacent iff they lie on a GQ line).
- Strongly regular parameters and eigen-spectrum.
- The full set of projective lines in PG(3,3) (130 total), split as 40 isotropic + 90 non-isotropic.
- The incidence graph (80 vertices) and the set of unique 8-cycles (girth-8 cycles).

Files:
- points.csv
- lines_iso_gq.csv
- lines_all_PG33.csv
- point_graph_edges.csv
- incidence_8cycles.csv
- w33_audit_summary.json

All computations are exact over GF(3) and are reproducible.
