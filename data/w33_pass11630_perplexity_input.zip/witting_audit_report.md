# Witting five-experiment audit

Executed using 40 explicit rays over Q(sqrt(-3)), numpy/scipy/networkx and exact SymPy checks.

## Main result
A Reye (12_4,16_3) configuration was found inside the 90 four-ray Witting projective lines. The 12 selected points meet exactly 16 of these lines in three points. The Levi graph is isomorphic to the V4 construction and to the real 24-cell Reye configuration. A nonsingular projective map was recovered with determinant 2/3; all 72 ray-proportionality minors vanish exactly. The map is not proportional to unitary, so this is an incidence bridge, not transport of a Peres KS proof. Novelty has not been assessed.

## Other completed experiments
- 90 rank-two qubit SIC planes, 40 qutrit MUB systems and 40 ququart bases verified.
- SIC-plane pair intersections: dimension one 1440, dimension zero 2565.
- SIC-plane/qutrit-hyperplane intersections: containment 360, dimension one 3240.
- 15 orthonormal traceless Hermitian generators and their commutator coefficients calculated; closure residual <1e-15.
- Tomography: 200000 simulated basis shots, trace distance 0.00949606.
- Independent binary witness: 200000 simulated shots, 9.9646 +/-0.036783 standard error; ideal 10, deterministic exclusivity bound 7. This is not an experiment or loophole-free certification.
- Explicit order-27 Heisenberg qutrit representation checked for all 729 products. Cayley graph explicitly isomorphic to the 27-point Witting residue.

## Reproduction
The accompanying Python script constructs the coordinates and performs the five experiments. scipy MILP has an 18-second limit; an incumbent is required for the final Reye certificate. The supplied witness is separately documented in the JSON and correspondence CSV. Floating-point checks are distinguished from exact symbolic checks.

## Source
Alexander Yu. Vlasov, Penrose Dodecahedron, Witting Configuration and Quantum Entanglement, arXiv:2208.13644v2. The paper supplies coordinate conventions, measurement bases, MUB incidence and 90 projective lines.
