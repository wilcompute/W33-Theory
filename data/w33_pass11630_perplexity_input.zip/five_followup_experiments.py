import numpy as np, networkx as nx, itertools, os, json, scipy.linalg as la
from collections import Counter, deque
import sympy as sp
os.makedirs('output',exist_ok=True)
w=np.exp(2j*np.pi/3)
rays=[np.eye(4,dtype=complex)[:,i] for i in range(4)]
for z in range(4):
    for a,b in itertools.product(range(3),repeat=2):rays.append(np.array([(0,1,-w**a,w**b),(1,0,-w**a,-w**b),(1,-w**a,0,w**b),(1,w**a,w**b,0)][z])/np.sqrt(3))
V=np.array(rays).T;inner=V.conj().T@V;A=np.isclose(np.abs(inner)**2,0,atol=1e-10);np.fill_diagonal(A,False);G=nx.from_numpy_array(A)
bases=sorted(tuple(sorted(c)) for c in nx.find_cliques(G));inds=list(nx.find_cliques(nx.complement(G)));sics=sorted(tuple(sorted(c)) for c in inds if len(c)==4)
Rset=frozenset([2,4,10,15,16,17,18,20,25,28,31,33]);Dset=frozenset([11,38,13,19,35,6,26,24,22,1,30,23]);Uset=Rset|Dset
sqrt3=sp.sqrt(3);Lex=sp.Matrix([[0,-sp.Rational(1,2)-sqrt3*sp.I/6,sp.Rational(1,2)-sqrt3*sp.I/6,sqrt3*sp.I/3],[0,-sp.Rational(1,2)+sqrt3*sp.I/6,0,-sp.Rational(1,2)+sqrt3*sp.I/6],[1,0,-sqrt3*sp.I/3,0],[0,-sp.Rational(1,2)-sqrt3*sp.I/6,-sp.Rational(1,2)+sqrt3*sp.I/6,sqrt3*sp.I/3]])
bmask=[sum(1<<i for i in b) for b in bases];coverage=[]
for c in inds:
    ss=set(c);coverage.append(sum(1<<j for j,b in enumerate(bases) if ss.intersection(b)))
missing=np.array([((1<<40)-1)^x for x in coverage],dtype=np.uint64)
def active_mask(S):
    sm=sum(1<<i for i in S)
    return sum(1<<j for j,bm in enumerate(bmask) if bm&sm==bm)
def colorable(S):return bool(np.any((missing&np.uint64(active_mask(S)))==0))
print({'base_union_colorable_with_all_pair_exclusivity':colorable(Uset),'baseline_tetrads':active_mask(Uset).bit_count(),'maximal_global_independent_sets':len(inds)})

outside=sorted(set(range(40))-Uset);minimal_extensions=[];tested=0
for k in range(17):
    for extra in itertools.combinations(outside,k):
        tested+=1
        if not colorable(Uset|set(extra)):minimal_extensions.append(extra)
    if minimal_extensions:break
witness=sorted(Uset|set(minimal_extensions[0]));critical=set(witness)
for i in list(witness):
    if not colorable(critical-{i}):critical.remove(i)
R={'KS_extension':{'minimum_added_rays':k,'number_of_minimum_extensions':len(minimal_extensions),'candidate_subsets_tested':tested,'example_added_ray_ids':list(minimal_extensions[0]),'example_superset_ray_ids':witness,'example_superset_tetrads':[list(b) for b in bases if set(b)<=set(witness)],'ray_deletion_critical_subset':sorted(critical),'critical_subset_tetrads':[list(b) for b in bases if set(b)<=critical],'criticality_verified':all(colorable(critical-{i}) for i in critical),'colorability_definition':'All pairwise orthogonal rays exclusive; exactly one outcome per complete contained tetrad'}}
P=np.array([np.outer(v,v.conj()) for v in rays]);gens=[]
for idx in [0,1,2,3,4,13,22,31]:
    Q=np.eye(4)+(w-1)*P[idx];scores=np.abs(V.conj().T@Q@V)**2
    assert np.allclose(scores.max(axis=0),1)
    gens.append(np.argmax(scores,axis=0).astype(np.uint8))
identity=np.arange(40,dtype=np.uint8);seen={identity.tobytes():identity};queue=deque([identity])
while queue:
    p=queue.popleft()
    for g in gens:
        q=p[g];key=q.tobytes()
        if key not in seen:seen[key]=q;queue.append(q)
        if len(seen)>60000:raise RuntimeError('unexpected group size')
group=list(seen.values())
def mask(S):return sum(1<<int(i) for i in S)
r_orbit=set();pair_orbit=set();r_stab=[];pair_stab=[]
for p in group:
    r=mask(p[list(Rset)]);d=mask(p[list(Dset)]);r_orbit.add(r);pair_orbit.add(tuple(sorted((r,d))))
    if r==mask(Rset):r_stab.append(p)
    if tuple(sorted((r,d)))==tuple(sorted((mask(Rset),mask(Dset)))):pair_stab.append(p)
R['symmetry']={'projective_unitary_group_order':len(group),'single_reye_orbit_size':len(r_orbit),'single_reye_setwise_stabilizer_order':len(r_stab),'unordered_paired_reye_orbit_size':len(pair_orbit),'unordered_pair_stabilizer_order':len(pair_stab),'scope':'Complete orbit of supplied witness under generated unitary group; not enumeration of all conceivable Reye embeddings'}
print(R)

metric=sp.simplify(Lex.conjugate().T*Lex)
trace=sp.simplify(sp.trace(metric));normalized=sp.simplify(metric/trace)
realR=[np.eye(4)[:,i] for i in range(4)]+[np.array((1,a,b,c))/2 for a,b,c in itertools.product([-1,1],repeat=3)]
correspondence=[2,25,16,28,10,17,31,18,15,33,20,4]
real_orth=np.isclose(np.abs(np.array(realR)@np.array(realR).T),0,atol=1e-9);mapped_orth=A[np.ix_(correspondence,correspondence)]
R['projective_distortion']={'determinant':str(sp.simplify(Lex.det())),'normalized_metric':[[str(normalized[i,j]) for j in range(4)] for i in range(4)],'normalized_metric_eigenvalues':{str(k):int(v) for k,v in normalized.eigenvals().items()},'condition_number':float(np.linalg.cond(np.array(Lex.evalf(),dtype=complex))),'real_internal_orthogonal_pairs':int(np.triu(real_orth,1).sum()),'image_internal_orthogonal_pairs':int(np.triu(mapped_orth,1).sum()),'preserved_internal_orthogonal_pairs':int(np.triu(real_orth&mapped_orth,1).sum()),'lost_internal_orthogonal_pairs':int(np.triu(real_orth&~mapped_orth,1).sum()),'created_internal_orthogonal_pairs':int(np.triu(~real_orth&mapped_orth,1).sum())}
def perm_order(p):
    seen=set();order=1
    for x in range(40):
        if x not in seen:
            cyc=[];y=x
            while y not in seen:seen.add(y);cyc.append(y);y=int(p[y])
            order=np.lcm(order,len(cyc))
    return int(order)
R['symmetry']['pair_stabilizer_element_orders']=dict(Counter(perm_order(p) for p in pair_stab))
R['symmetry']['pair_stabilizer_center_order']=sum(all(np.array_equal(p[q],q[p]) for q in pair_stab) for p in pair_stab)
R['symmetry']['single_stabilizer_element_orders']=dict(Counter(perm_order(p) for p in r_stab))
print(R['projective_distortion']);print(R['symmetry'])

NG=nx.complement(G);edges=sorted(tuple(sorted(e)) for e in NG.edges());eidx={e:i for i,e in enumerate(edges)}
triangles=[c for c in itertools.combinations(range(40),3) if all(NG.has_edge(a,b) for a,b in itertools.combinations(c,2))]
pivots={}
for i,j,k in triangles:
    bits=(1<<eidx[(i,j)])^(1<<eidx[(i,k)])^(1<<eidx[(j,k)])
    while bits:
        q=bits.bit_length()-1
        if q in pivots:bits^=pivots[q]
        else:pivots[q]=bits;break
cycle_dim=len(edges)-40+1
T=np.einsum('ij,jk,ki->ijk',inner,inner,inner)
phase_counts=Counter(round(float(np.angle(T[i,j,k])/np.pi),8) for i,j,k in triangles)
tree=nx.minimum_spanning_tree(NG);theta=np.zeros(40)
for u,v in nx.bfs_edges(tree,0):theta[v]=theta[u]-np.angle(inner[u,v])
gauged=inner*np.exp(1j*(theta[None,:]-theta[:,None]))
known=np.eye(40,dtype=bool);reconstructed=np.eye(40,dtype=complex)
for u,v in tree.edges():known[u,v]=known[v,u]=True;reconstructed[u,v]=reconstructed[v,u]=1/np.sqrt(3)
changed=True
while changed:
    changed=False
    for i,j,k in triangles:
        links=[(i,j),(j,k),(k,i)];unknown=[(u,v) for u,v in links if not known[u,v]]
        if len(unknown)==1:
            u,v=unknown[0];prod=np.prod([reconstructed[a,b] for a,b in links if known[a,b]])
            reconstructed[u,v]=T[i,j,k]/prod;reconstructed[v,u]=reconstructed[u,v].conjugate();known[u,v]=known[v,u]=True;changed=True
unresolved=[e for e in edges if not known[e]]
R['triple_products']={'nonorthogonality_edges':len(edges),'nonorthogonal_triangles':len(triangles),'triangle_boundary_rank_mod2':len(pivots),'cycle_space_dimension':cycle_dim,'first_homology_dimension_mod2':cycle_dim-len(pivots),'triangle_phase_counts_pi_units':dict(phase_counts),'tree_seed_edges':39,'triangle_propagation_unresolved_edges':len(unresolved),'reconstruction_residual_if_complete':float(np.linalg.norm(reconstructed-gauged)) if not unresolved else None,'scope':'Homology mod2 and constructive propagation; no unproved global uniqueness claim'}
print(R['triple_products'])

F3=list(itertools.product(range(3),repeat=3));X=np.roll(np.eye(3),1,axis=0);Z=np.diag(w**np.arange(3))
def D(g):
    a,b,c=g;return w**((a+b*c)%3)*np.linalg.matrix_power(X,(2*b)%3)@np.linalg.matrix_power(Z,c)
Ds=np.array([D(g) for g in F3]);FF=np.array([[w**(j*k) for k in range(3)] for j in range(3)])/np.sqrt(3);S=np.diag([w**((2*j*j)%3) for j in range(3)])
cliff=[X,Z,FF,S];cg=[]
for U in cliff:
    imgs=np.array([U@d@U.conj().T for d in Ds]);cost=np.linalg.norm(imgs[:,None]-Ds[None,:],axis=(2,3));assert cost.min(axis=1).max()<1e-9
    cg.append(np.argmin(cost,axis=1).astype(np.uint8))
id27=np.arange(27,dtype=np.uint8);cseen={id27.tobytes():id27};cq=deque([id27])
while cq:
    p=cq.popleft()
    for g in cg:
        q=p[g];key=q.tobytes()
        if key not in cseen:cseen[key]=q;cq.append(q)
subspace=la.null_space(V[:,0].conj()[None,:]);local_rays=sorted(G.neighbors(0));W=subspace.conj().T@V[:,local_rays]
local_bases=[tuple(local_rays.index(j) for j in b if j!=0) for b in bases if 0 in b]
local_perms=set();local_phase_perms=set()
for p in group:
    if int(p[0])==0:
        lp=tuple(local_rays.index(int(p[i])) for i in local_rays);local_perms.add(lp)
        old=W.conj().T@W;new=old[np.ix_(lp,lp)];tt=np.einsum('ij,jk,ki->ijk',old,old,old);tn=np.einsum('ij,jk,ki->ijk',new,new,new)
        if np.allclose(tt,tn,atol=1e-9):local_phase_perms.add(lp)
anchor_stab=[p for p in group if int(p[0])==0]
hesse_fid=np.array([0,1,-1],dtype=complex)/np.sqrt(2)
HS=np.array([np.linalg.matrix_power(X,b)@np.linalg.matrix_power(Z,c)@hesse_fid for b,c in itertools.product(range(3),repeat=2)]).T
sic_ok=np.allclose(np.abs(HS.conj().T@HS)**2,np.eye(9)+(.25)*(np.ones((9,9))-np.eye(9)))
hesse_gens=[]
for U in cliff:
    score=np.abs(HS.conj().T@U@HS)**2
    hesse_gens.append(np.argmax(score,axis=0).astype(np.uint8));assert np.allclose(score.max(axis=0),1)
ids=np.arange(9,dtype=np.uint8);hs={ids.tobytes():ids};hq=deque([ids])
while hq:
    p=hq.popleft()
    for g in hesse_gens:
        q=p[g];key=q.tobytes()
        if key not in hs:hs[key]=q;hq.append(q)
R['hesse_match']={'heisenberg_conjugation_group_order':len(cseen),'hesse_sic_verified':bool(sic_ok),'hesse_nine_ray_permutation_group_order':len(hs),'witting_anchor_stabilizer_order':len(anchor_stab),'faithful_action_on_local_12_mub_rays_order':len(local_perms),'phase_preserving_local_action_order':len(local_phase_perms),'local_action_kernel_order':len(anchor_stab)//len(local_perms),'scope':'Counts and direct representations checked; explicit intertwiner between local Witting MUB action and canonical Clifford action still to be certified'}
print(R['hesse_match'])

canonical=[np.eye(3,dtype=complex)[:,j] for j in range(3)]
for t in range(3):
    evs,vecs=np.linalg.eig(X@np.linalg.matrix_power(Z,t))
    canonical.extend(vecs[:,j]/np.linalg.norm(vecs[:,j]) for j in range(3))
K=np.array(canonical).T;Jlocal=np.diag([1,-1,1]);scores=np.abs(K.conj().T@Jlocal@W)**2
matching=np.argmax(scores,axis=0);assert len(set(matching))==12 and np.allclose(scores.max(axis=0),1)
canonical_gens=[]
for U in cliff:
    score=np.abs(K.conj().T@U@K)**2;assert np.allclose(score.max(axis=0),1)
    canonical_gens.append(np.argmax(score,axis=0).astype(np.uint8))
id12=np.arange(12,dtype=np.uint8);cs={id12.tobytes():id12};qq=deque([id12])
while qq:
    p=qq.popleft()
    for g in canonical_gens:
        q=p[g];key=q.tobytes()
        if key not in cs:cs[key]=q;qq.append(q)
inv_matching=np.argsort(matching)
transported={tuple(int(matching[lp[int(inv_matching[j])]]) for j in range(12)) for lp in local_perms}
canonset={tuple(map(int,p)) for p in cs.values()}
quotient_actions=set()
for p in cseen.values():
    quotient_actions.add(tuple(F3[int(p[F3.index((0,b,c))])][1:] for b,c in itertools.product(range(3),repeat=2)))
R['hesse_match'].update({'explicit_intertwiner_in_chosen_local_basis':[[1,0,0],[0,-1,0],[0,0,1]],'local_mub_to_canonical_ray_correspondence':matching.tolist(),'maximum_ray_matching_residual':float(np.max(1-scores.max(axis=0))),'transported_local_group_equals_canonical_clifford_group':transported==canonset,'symplectic_quotient_action_order':len(quotient_actions),'inner_translation_kernel_order':len(cseen)//len(quotient_actions),'scope':'Explicit unitary ray matching and equality of all 216 transported permutations verified numerically; finite action equality exact on permutations'})
print(R['hesse_match'])

from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
C=sorted(critical);cb=[b for b in bases if set(b)<=critical];cedges=[(i,j) for i,j in G.edges() if i in critical and j in critical]
M=np.array([[int(i in b) for i in C] for b in cb]);basis_only=milp(np.zeros(len(C)),integrality=np.ones(len(C)),bounds=Bounds(0,1),constraints=LinearConstraint(M,1,1))
M2=np.vstack([M,[[int(i in e) for i in C] for e in cedges]])
fullmilp=milp(np.zeros(len(C)),integrality=np.ones(len(C)),bounds=Bounds(0,1),constraints=LinearConstraint(M2,np.r_[np.ones(len(cb)),np.zeros(len(cedges))],np.ones(len(cb)+len(cedges))))
deletion_witnesses={}
for i in C:
    s=critical-{i};am=np.uint64(active_mask(s));idx=int(np.flatnonzero((missing&am)==0)[0]);deletion_witnesses[str(i)]=sorted(set(inds[idx])&s)
extset={frozenset(e) for e in minimal_extensions};extorbits=[]
while extset:
    e=next(iter(extset));orb={frozenset(map(int,p[list(e)])) for p in pair_stab};assert orb<=set(map(frozenset,minimal_extensions));extorbits.append(len(orb));extset-=orb
R['KS_extension'].update({'critical_orthogonality_edges':len(cedges),'basis_only_feasibility_status':int(basis_only.status),'full_exclusivity_feasibility_status':int(fullmilp.status),'deletion_coloring_witnesses':deletion_witnesses,'minimum_extension_orbits_under_pair_stabilizer':sorted(extorbits),'global_minimum_claim':False})
print({k:R['KS_extension'][k] for k in ['critical_orthogonality_edges','basis_only_feasibility_status','full_exclusivity_feasibility_status','minimum_extension_orbits_under_pair_stabilizer']})

known=np.eye(40,dtype=bool);RR=np.eye(40,dtype=complex)
for u,v in tree.edges():known[u,v]=known[v,u]=True;RR[u,v]=RR[v,u]=1/np.sqrt(3)
steps=[]
while True:
    added=0
    for i,j,k in triangles:
        links=[(i,j),(j,k),(k,i)];unknown=[(u,v) for u,v in links if not known[u,v]]
        if len(unknown)==1:
            u,v=unknown[0];prod=np.prod([RR[a,b] for a,b in links if known[a,b]]);RR[u,v]=T[i,j,k]/prod;RR[v,u]=RR[u,v].conjugate();known[u,v]=known[v,u]=True
            steps.append({'triangle':[i,j,k],'recovered_oriented_edge':[u,v],'triple_product':[float(T[i,j,k].real),float(T[i,j,k].imag)]});added+=1
    if not added:break
R['triple_products'].update({'reconstruction_steps':len(steps),'scope':'The 501-step triangle propagation certificate determines every remaining Gram entry from a positive spanning-tree gauge and the labeled triple products; hence fixes a rank-four realization up to unitary equivalence. Numerical consistency residual reported separately.'})
def native(x):
    if isinstance(x,dict):return {str(k):native(v) for k,v in x.items()}
    if isinstance(x,(list,tuple,set,frozenset)):return [native(v) for v in x]
    if isinstance(x,np.generic):return x.item()
    return x
with open('output/five_followup_results.json','w') as f:json.dump(native(R),f,indent=2)
with open('output/gram_reconstruction_certificate.json','w') as f:json.dump({'spanning_tree_edges':[list(e) for e in tree.edges()],'steps':steps},f,indent=2)
np.savez_compressed('output/witting_symmetry_and_phase_data.npz',rays=V,unitary_group_permutations=np.array(group),paired_reye_stabilizer=np.array(pair_stab),triple_products=T,local_intertwiner=Jlocal,canonical_qutrit_mub_rays=K)
report='''# Five Witting follow-up experiments\n\nAll five were executed on explicit 40-ray coordinates. Novelty has not been assessed.\n\n## KS extension\nThe supplied 24-ray paired-Reye union needs a minimum of six additional Witting rays under pairwise orthogonality exclusivity and one-per-contained-tetrad constraints. Exhaustive search examined 14893 candidates through size six. There are 48 minimum extensions, one orbit under the 96-element pair stabilizer. One 30-ray/16-tetrad extension reduces to a ray-deletion-critical 29-ray/14-tetrad configuration with 132 orthogonality edges. It is NOT uncolorable from the fourteen tetrad equations alone: pair exclusivity is essential. Minimality is only relative to extensions of the specified 24-ray union; no global minimum claim is made. Deletion colorings are included.\n\n## Symmetry\nGenerated projective unitary group: 25920. Witness Reye orbit: 540, stabilizer 48. Unordered paired-Reye orbit: 270, stabilizer 96, center order two. This classifies this orbit, not all conceivable Reye embeddings.\n\n## Distortion\nFor normalized L^dagger L, eigenvalues are (3-sqrt(3))/12 and (3+sqrt(3))/12, each twice. Condition number sqrt(2+sqrt(3)). Of 18 internal orthogonal pairs in the real Reye, 12 survive and six disappear. No internal orthogonality is created.\n\n## Phases\nNonorthogonality graph: 540 edges, 3240 triangles. Triangle-boundary rank modulo two 501, equal to cycle-space dimension. A constructive spanning-tree gauge followed by 501 triangle updates reconstructs all edges, residual 4.65e-15. The update certificate implies uniqueness for the specified labeled triple products, up to ray gauge and unitary equivalence; support alone does not imply uniqueness.\n\n## Hesse/Clifford\nThe Witting anchor stabilizer has order 648. Its local twelve-MUB-ray action has order 216 and kernel three. The explicit local intertwiner diag(1,-1,1) maps these rays to canonical qutrit stabilizer MUB rays. All 216 transported permutations equal the Fourier/phase/Pauli generated Clifford permutations. The same canonical generators preserve the nine Hesse SIC rays. The Heisenberg-conjugation quotient has order24 and kernel9. Matrix checks numerical; permutation set equality finite/exact.\n\n## Reproduction\nThe supplied script is assembled from the executed cells and syntax-checked; it was not separately rerun as a fresh process. Dependencies: numpy, scipy, networkx, sympy. The symmetry and Gram data are supplied in NPZ, with JSON certificates for searches and reconstruction.\n'''
with open('output/five_followup_audit.md','w') as f:f.write(report)
