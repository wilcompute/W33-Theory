import numpy as np, itertools, networkx as nx, os, json, scipy.linalg as la
os.makedirs('output',exist_ok=True)
w=np.exp(2j*np.pi/3)
rays=[np.eye(4,dtype=complex)[:,i] for i in range(4)]
labels=[f'e{i}' for i in range(4)]
for zero in range(4):
    for a,b in itertools.product(range(3),repeat=2):
        v=[(0,1,-w**a,w**b),(1,0,-w**a,-w**b),(1,-w**a,0,w**b),(1,w**a,w**b,0)][zero]
        rays.append(np.array(v)/np.sqrt(3));labels.append(f'z{zero}_a{a}_b{b}')
V=np.array(rays).T; overlap=np.abs(V.conj().T@V)**2
A=np.isclose(overlap,0,atol=1e-10);np.fill_diagonal(A,False);G=nx.from_numpy_array(A)
bases=sorted(tuple(sorted(c)) for c in nx.find_cliques(G))
nonorth=list(nx.find_cliques(nx.complement(G)));sics=sorted(tuple(sorted(c)) for c in nonorth if len(c)==4)
print({'degrees':sorted(set(dict(G.degree()).values())),'bases':len(bases),'base_sizes':sorted(set(map(len,bases))),'max_nonorth':max(map(len,nonorth)),'sics':len(sics),'sic_span_ranks':sorted(set(np.linalg.matrix_rank(V[:,c],tol=1e-9) for c in sics)),'overlaps':np.unique(np.round(overlap,9)).tolist()})
import sympy as sp
from fractions import Fraction
def native(x):
    if isinstance(x,dict): return {str(k):native(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [native(v) for v in x]
    if isinstance(x,np.generic): return x.item()
    return x

import pandas as pd
Proj=np.array([np.outer(v,v.conj()) for v in rays])
sic_Q=[la.orth(V[:,c]) for c in sics];sic_projectors=[q@q.conj().T for q in sic_Q]
MUBs=[]
for i in range(40):
    triples=[tuple(j for j in b if j!=i) for b in bases if i in b]
    MUBs.append({'anchor':i,'triples':triples})
from collections import Counter
ss=Counter(4-np.linalg.matrix_rank(np.column_stack([sic_Q[i],sic_Q[j]]),tol=1e-8) for i in range(90) for j in range(i))
sh=Counter(2-np.linalg.matrix_rank(rays[i].conj()[None,:]@sic_Q[j],tol=1e-8) for i in range(40) for j in range(90))
basis_rows=[{'basis_id':i,'ray_ids':','.join(map(str,b))} for i,b in enumerate(bases)]
sic_rows=[{'sic_id':i,'ray_ids':','.join(map(str,c))} for i,c in enumerate(sics)]
pd.DataFrame(basis_rows).to_csv('output/witting_bases.csv',index=False)
pd.DataFrame(sic_rows).to_csv('output/witting_sics.csv',index=False)
B=np.real(np.einsum('iab,jba->ij',Proj,Proj));ev,U=np.linalg.eigh(A.astype(float));Q=U[:,np.isclose(ev,-4)]
F=np.einsum('ia,ijk->ajk',Q,Proj)/np.sqrt(2)
C=np.empty((15,15,15))
for a in range(15):
    for b in range(15):C[a,b]=np.real(np.einsum('kij,ji->k',F,-1j*(F[a]@F[b]-F[b]@F[a])))
closure=max(np.linalg.norm(-1j*(F[a]@F[b]-F[b]@F[a])-np.einsum('k,kij->ij',C[a,b],F)) for a in range(15) for b in range(15))
rows=[{'a':a,'b':b,'c':c,'coefficient':C[a,b,c]} for a,b,c in itertools.product(range(15),repeat=3) if abs(C[a,b,c])>1e-9]
pd.DataFrame(rows).to_csv('output/su4_structure_constants.csv',index=False)
np.savez_compressed('output/witting_operators.npz',rays=V,projectors=Proj,operator_basis=F,structure_constants=C)
T=np.einsum('ij,jk,ki->ijk',V.conj().T@V,V.conj().T@V,V.conj().T@V)
tri=[T[i,j,k] for i,j,k in itertools.combinations(range(40),3) if all(not A[a,b] for a,b in [(i,j),(j,k),(i,k)])]
results={'atlas':{'rays':40,'bases':40,'sic_planes':90,'qutrit_mub_systems':40,'sic_sic_intersection_dimensions':dict(ss),'sic_qutrit_intersection_dimensions':dict(sh),'sic_tight_frame_max_residual':max(np.linalg.norm(Proj[list(c)].sum(axis=0)-2*sic_projectors[i]) for i,c in enumerate(sics))},'operator_algebra':{'gram_relation_residual':float(np.linalg.norm(B-(2*np.eye(40)+np.ones((40,40))-A)/3)),'orthonormality_residual':float(np.linalg.norm(np.einsum('aij,bji->ab',F,F)-np.eye(15))),'commutator_closure_residual':float(closure),'nonorthogonal_triangle_triple_products':sorted(set((round(z.real,9),round(z.imag,9)) for z in tri))}}
results

from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix
inc=[(i,l) for l,c in enumerate(sics) for i in c];n=40+90+len(inc)
rows=[];lower=[];upper=[]
def constraint(entries,lo,hi):rows.append(entries);lower.append(lo);upper.append(hi)
constraint({i:1 for i in range(40)},12,12)
constraint({40+l:1 for l in range(90)},16,16)
for l,c in enumerate(sics):
    constraint({**{i:1 for i in c},40+l:-3},0,np.inf)
    constraint({**{i:1 for i in c},40+l:1},-np.inf,4)
for k,(i,l) in enumerate(inc):
    z=130+k
    constraint({z:1,i:-1},-np.inf,0);constraint({z:1,40+l:-1},-np.inf,0)
    constraint({z:1,i:-1,40+l:-1},-1,np.inf)
for i in range(40):constraint({**{130+k:1 for k,(j,l) in enumerate(inc) if j==i},i:-4},0,0)
M=lil_matrix((len(rows),n))
for j,row in enumerate(rows):
    for k,val in row.items():M[j,k]=val
res=milp(np.zeros(n),integrality=np.ones(n),bounds=Bounds(0,1),constraints=LinearConstraint(M.tocsr(),lower,upper),options={'time_limit':18})
results['reye_search']={'method':'MILP necessary induced (12_4,16_3) subconfiguration in 90 SIC lines','status':int(res.status),'message':res.message,'has_incumbent':res.x is not None}
if res.x is not None:
    selected_points=np.flatnonzero(res.x[:40]>.5).tolist();selected_lines=np.flatnonzero(res.x[40:130]>.5).tolist()
    target=nx.Graph();target.add_nodes_from([('p',i) for i in selected_points],bipartite=0);target.add_nodes_from([('l',l) for l in selected_lines],bipartite=1)
    target.add_edges_from((('p',i),('l',l)) for l in selected_lines for i in sics[l] if i in selected_points)
    R=nx.Graph()
    for family in range(3):R.add_nodes_from([('p',family,i) for i in range(4)],bipartite=0)
    for a,b in itertools.product(range(4),repeat=2):
        line=('l',a,b);R.add_node(line,bipartite=1)
        R.add_edges_from((line,('p',fam,val)) for fam,val in [(0,a),(1,b),(2,a^b)])
    results['reye_search'].update({'selected_points':selected_points,'selected_lines':selected_lines,'is_reye':nx.is_isomorphic(R,target,node_match=nx.algorithms.isomorphism.categorical_node_match('bipartite',-1))})
results['reye_search']

rng=np.random.default_rng(20261007)
psi=rng.normal(size=4)+1j*rng.normal(size=4);psi/=np.linalg.norm(psi)
rho=.7*np.outer(psi,psi.conj())+.3*np.eye(4)/4
ray_probs=np.real(np.einsum('ij,kji->k',rho,Proj));counts=np.zeros(40,dtype=int);N=5000
for b in bases:counts[list(b)]+=rng.multinomial(N,ray_probs[list(b)])
p=counts/(40*N);rhohat=5*np.einsum('i,ijk->jk',p,Proj)-np.eye(4)
binary=rng.binomial(N,ray_probs);witness=binary.sum()/N
results['simulation']={'seed':20261007,'state':'0.7 random pure state +0.3 maximally mixed','basis_measurement_shots':40*N,'binary_measurement_shots':40*N,'tomography_frobenius_error':float(np.linalg.norm(rhohat-rho)),'tomography_trace_distance':float(np.sum(np.abs(np.linalg.eigvalsh(rhohat-rho)))/2),'estimated_eigenvalues':np.linalg.eigvalsh(rhohat).tolist(),'true_purity':float(np.trace(rho@rho).real),'estimated_purity_probability_formula':float(50*np.sum(p*p)-1),'independent_binary_witness':float(witness),'ideal_witness':float(ray_probs.sum()),'binary_witness_standard_error':float(np.sqrt(np.sum(ray_probs*(1-ray_probs))/N)),'classical_bound':7}
F3=list(itertools.product(range(3),repeat=3))
def product(g,h):
    a,b,c=g;ap,bp,cp=h
    return ((a+ap-b*cp+c*bp)%3,(b+bp)%3,(c+cp)%3)
X=np.roll(np.eye(3),1,axis=0);Z=np.diag(w**np.arange(3))
def rep(g):
    a,b,c=g
    return w**((a+b*c)%3)*np.linalg.matrix_power(X,(2*b)%3)@np.linalg.matrix_power(Z,c)
resid=max(np.linalg.norm(rep(g)@rep(h)-rep(product(g,h))) for g,h in itertools.product(F3,repeat=2))
CG=nx.Graph();CG.add_nodes_from(F3)
for g in F3:
    for b,c in itertools.product(range(3),repeat=2):
        if (b,c)!=(0,0):CG.add_edge(g,product(g,(0,b,c)))
H=G.subgraph([i for i in range(40) if i!=0 and not A[0,i]]).copy()
gm=nx.algorithms.isomorphism.GraphMatcher(CG,H);ok=gm.is_isomorphic()
results['heisenberg']={'order':27,'center':[(a,0,0) for a in range(3)],'quotient':'F3^2','qutrit_representation_product_checks':729,'maximum_product_residual':float(resid),'cayley_graph_isomorphic_to_witting_27_residue':ok,'explicit_isomorphism':{str(k):v for k,v in gm.mapping.items()} if ok else None}
real_reye=[np.eye(4)[:,i] for i in range(4)]+[np.array((1,a,b,c))/2 for a,b,c in itertools.product([-1,1],repeat=3)]
real_lines=[c for c in itertools.combinations(range(12),3) if np.linalg.matrix_rank(np.array(real_reye)[list(c)],tol=1e-9)==2]
RR=nx.Graph();RR.add_nodes_from([('p',i) for i in range(12)],bipartite=0)
for l,c in enumerate(real_lines):
    RR.add_node(('l',l),bipartite=1);RR.add_edges_from((('p',i),('l',l)) for i in c)
rgm=nx.algorithms.isomorphism.GraphMatcher(RR,target,node_match=nx.algorithms.isomorphism.categorical_node_match('bipartite',-1));real_ok=rgm.is_isomorphic()
map_rays={i:rgm.mapping[('p',i)][1] for i in range(12)}
Mcomplex=np.zeros((48,28),dtype=complex)
for i in range(12):
    r=real_reye[i];v=rays[map_rays[i]]
    for j in range(4):Mcomplex[4*i+j,4*j:4*j+4]=r;Mcomplex[4*i+j,16+i]=-v[j]
null=la.null_space(Mcomplex,rcond=1e-10)
projective={ 'real_24_cell_reye_lines':len(real_lines),'real_reye_incidence_isomorphism':real_ok,'projective_equivalence_nullity':null.shape[1]}
if null.shape[1]:
    L=null[:16,0].reshape(4,4);L/=np.linalg.norm(L)
    projective.update({'map_rank':int(np.linalg.matrix_rank(L)),'singular_values':np.linalg.svd(L,compute_uv=False).tolist(),'ray_matching_max_residual':float(max(np.linalg.norm((np.eye(4)-Proj[map_rays[i]])@L@real_reye[i]) for i in range(12)))})
    np.savez_compressed('output/reye_embedding.npz',selected_points=selected_points,selected_lines=selected_lines,real_reye_rays=np.array(real_reye),real_to_witting_map=L,point_correspondence=np.array([map_rays[i] for i in range(12)]))
results['reye_search']['all_sic_line_intersection_sizes']=dict(Counter(len(set(c)&set(selected_points)) for c in sics))
results['reye_search']['projective_equivalence']=projective
results['simulation'],results['heisenberg']['maximum_product_residual'],results['reye_search']

pivot=L.flat[np.argmax(np.abs(L))];Ln=L/pivot
from fractions import Fraction
Lex=sp.Matrix(4,4,lambda i,j:sp.Rational(str(Fraction(float(Ln[int(i),int(j)].real)).limit_denominator(24)))+sp.I*sp.sqrt(3)*sp.Rational(str(Fraction(float(Ln[int(i),int(j)].imag/np.sqrt(3))).limit_denominator(24))))
we=(-1+sp.I*sp.sqrt(3))/2;Ve=[sp.eye(4)[:,i] for i in range(4)]
for z in range(4):
    for a,b in itertools.product(range(3),repeat=2):Ve.append(sp.Matrix([(0,1,-we**a,we**b),(1,0,-we**a,-we**b),(1,-we**a,0,we**b),(1,we**a,we**b,0)][z]))
exact_checks=[]
for i in range(12):
    rr=sp.Matrix([sp.Rational(str(float(x))) for x in real_reye[i]]);lv=Lex*rr;vv=Ve[map_rays[i]]
    exact_checks.extend(sp.simplify(sp.expand(lv[a]*vv[b]-lv[b]*vv[a]))==0 for a,b in itertools.combinations(range(4),2))
results['reye_search']['projective_equivalence'].update({'exact_projective_matrix':[[str(Lex[i,j]) for j in range(4)] for i in range(4)],'exact_collinearity_minor_checks':len(exact_checks),'all_exact_checks_pass':all(exact_checks),'exact_determinant':str(sp.simplify(Lex.det())),'point_correspondence':map_rays})
pd.DataFrame([{'real_reye_id':i,'witting_ray_id':map_rays[i],'witting_label':labels[map_rays[i]]} for i in range(12)]).to_csv('output/reye_point_correspondence.csv',index=False)
with open('output/witting_experiment_results.json','w') as f:json.dump(native(results),f,indent=2)
print(Lex)
print({'exact_checks':all(exact_checks),'determinant':sp.simplify(Lex.det()),'correspondence':map_rays})