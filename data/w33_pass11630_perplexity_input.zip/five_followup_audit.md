# Five Witting follow-up experiments

All five were executed on explicit 40-ray coordinates. Novelty has not been assessed.

## KS extension
The supplied 24-ray paired-Reye union needs a minimum of six additional Witting rays under pairwise orthogonality exclusivity and one-per-contained-tetrad constraints. Exhaustive search examined 14893 candidates through size six. There are 48 minimum extensions, one orbit under the 96-element pair stabilizer. One 30-ray/16-tetrad extension reduces to a ray-deletion-critical 29-ray/14-tetrad configuration with 132 orthogonality edges. It is NOT uncolorable from the fourteen tetrad equations alone: pair exclusivity is essential. Minimality is only relative to extensions of the specified 24-ray union; no global minimum claim is made. Deletion colorings are included.

## Symmetry
Generated projective unitary group: 25920. Witness Reye orbit: 540, stabilizer 48. Unordered paired-Reye orbit: 270, stabilizer 96, center order two. This classifies this orbit, not all conceivable Reye embeddings.

## Distortion
For normalized L^dagger L, eigenvalues are (3-sqrt(3))/12 and (3+sqrt(3))/12, each twice. Condition number sqrt(2+sqrt(3)). Of 18 internal orthogonal pairs in the real Reye, 12 survive and six disappear. No internal orthogonality is created.

## Phases
Nonorthogonality graph: 540 edges, 3240 triangles. Triangle-boundary rank modulo two 501, equal to cycle-space dimension. A constructive spanning-tree gauge followed by 501 triangle updates reconstructs all edges, residual 4.65e-15. The update certificate implies uniqueness for the specified labeled triple products, up to ray gauge and unitary equivalence; support alone does not imply uniqueness.

## Hesse/Clifford
The Witting anchor stabilizer has order 648. Its local twelve-MUB-ray action has order 216 and kernel three. The explicit local intertwiner diag(1,-1,1) maps these rays to canonical qutrit stabilizer MUB rays. All 216 transported permutations equal the Fourier/phase/Pauli generated Clifford permutations. The same canonical generators preserve the nine Hesse SIC rays. The Heisenberg-conjugation quotient has order24 and kernel9. Matrix checks numerical; permutation set equality finite/exact.

## Reproduction
The supplied script is assembled from the executed cells and syntax-checked; it was not separately rerun as a fresh process. Dependencies: numpy, scipy, networkx, sympy. The symmetry and Gram data are supplied in NPZ, with JSON certificates for searches and reconstruction.
