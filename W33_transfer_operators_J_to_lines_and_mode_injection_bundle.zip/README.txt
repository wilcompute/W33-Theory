Transfer operators from tetra flux J:=dF to 90-line observables

This bundle constructs two explicit Z3-linear maps:
  - M (boundary moment): adds J(t) to the unique attached nonisotropic line for boundary tetrahedra (flat_face_count=1)
  - Z (bulk shadow): for each curved face of a tetrahedron t, pushes J(t) along the 3 edges of that face, mapping each edge to its unique nonisotropic line.

Files:
  - operator_M_coo.csv, operator_Z_coo.csv
      Sparse COO representation (row_line_id, col_tet_index, value_mod3).
  - tetrahedra_J_dF_9450.csv
      Full tetra list with J and boundary attachment metadata.
  - line_vectors_from_MZJ_mod3.csv
      Resulting m_raw, m_aug (sum=0 gauge), and z vectors on the 90 lines.
  - mode_injection_by_orbit_and_flux.csv, mode_injection_aggregate_by_orbit.csv
      Mode-energy fractions (after embedding 2->-1 and mean-removal) by tetra orbit and flux sign.
  - report.json
