# Preimage pairing structure for the 120-root set

We start with the 240 minimal weight-6 codewords in ker(A) (A is W33 adjacency over GF(2)).
Each generator is obtained as XOR of two isotropic GQ lines through a common point p.

Projecting each generator to H := ker(A)/im(A) yields 120 distinct nonzero H-elements ("roots"),
each occurring exactly twice.

Empirical structure (proved by enumeration):
- The two generators mapping to the same root always share the same base point p.
- Their XOR (difference in GF(2)^40) is always the indicator of the 12 neighbors of p in the W33 point graph.
- Therefore, each point p contributes 3 distinct roots (6 line-pairs grouped into 3 complementary pairs).

File root_preimages_120.csv lists, for each root:
- its base point p
- the two generator IDs and their defining line pairs
- the 12-point XOR difference (neighbors of p)

