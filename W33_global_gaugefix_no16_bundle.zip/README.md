# Global gauge-fix eliminating all 16-weight defects

We consider the 120 projective roots (q=1 orbit in H) and their 2-to-1 lifts to 240 minimal generators in ker(A) ⊂ F2^40.

Each root vertex v has two generator lifts:
  genA(v), genB(v)  (both weight-6 subsets of the 40 W33 points)

For every edge (u,v) in SRG(120,56,28,24), define the third vertex c = u ⊕ v in H (also a root).
Then define the signed-triple defect (in F2^40):
  D(u,v) = gen(u) ⊕ gen(v) ⊕ gen(c)

In the canonical section this defect has weight 12 or 16.

## Greedy gauge-fix
We choose a binary variable x[v] ∈ {0,1} selecting genA/genB at each vertex.
We perform greedy flips of x[v] whenever it reduces the number of 16-defects (or keeps that count but reduces total weight).

Starting from x ≡ 0, we reach a configuration with:
  - 0 edges of weight 16
  - 3240 edges of weight 12
  - 120 edges of weight 0
Total weight = 38880.

## Structure of the 0-weight edges
The 120 zero edges group into 40 triangles (each triangle contributes 3 edges),
and each such triangle consists of the 3 roots that share a common base point p in the original W33 geometry.

Thus the 120 vertices partition into 40 triples by base point, and exactly those 40 triples become *flat* (defect 0).

## Files
- assignment_vertex_choices.csv / .json: the chosen x[v] and selected generator IDs
- edge_triples_with_weights_3360.csv: every edge (u,v,c) with its defect weight (0 or 12)
- steiner_triples_with_weights_1120.csv: each triple (0, 81, 80) with its (constant) defect weight
- zero_triangles_by_base_point_40.csv: the 40 flat triangles indexed by base point

