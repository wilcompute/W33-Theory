W33 GF(2) kernel code artifacts

Source geometry: /mnt/data/W33_symplectic_audit_bundle.zip (W(3,3) point graph SRG(40,12,2,4))

Define A = 40x40 adjacency matrix of the W33 point graph.
Define code C = {x in GF(2)^40 : A x = 0}.

Computed facts:
- rank_GF2(A) = 16
- dim(C) = 40 - rank(A) = 24
- minimum weight <= 6 is 6
- We exhibit 240 weight-6 codewords, each = XOR of two isotropic GQ lines through a common point.
  (For each point p, choose two of its 4 incident GQ lines; there are C(4,2)=6 per point, so 40*6=240.)

Files:
- generators_weight6_linepair_xors.csv : the 240 minimal generators (support points, and their defining line pairs)
- code_basis_24x40.csv : a row-reduced basis for C (24 generators)

