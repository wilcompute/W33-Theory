# Signed-root lift and cocycle from W33

## Setup
- W33 point graph: SRG(40,12,2,4) with adjacency matrix A over GF(2).
- SRG identity implies A^2 ≡ 0 (mod 2), giving an extension:
    0 → im(A) → ker(A) → H → 0
  where H = ker(A)/im(A), dim(H)=8.
- The 240 minimal weight-6 generators in ker(A) project 2-to-1 onto 120 nonsingular (q=1) elements in H.
  These 120 elements form SRG(120,56,28,24) with adjacency b=1.

## Canonical section and cocycle
Choose the canonical section s(h) as the smaller of the two generator IDs mapping to each projective root h (120 roots).

For any adjacent pair (h1,h2) (i.e. b(h1,h2)=1), define h3 = h1 ⊕ h2 in H.
Then define the im(A)-valued cocycle:
    g(h1,h2) := s(h1) ⊕ s(h2) ⊕ s(h3)   ∈ im(A).

Empirical results (for the canonical section):
- g(h1,h2) always lies in im(A).
- Its 40-point support weight is ALWAYS either 12 or 16.
  Edge counts on SRG(120): weight-12 occurs 1560 times; weight-16 occurs 1800 times.

## Steiner triples
Because for b=1 we have q(h1⊕h2)=1, each edge (h1,h2) determines a unique third root h3=h1⊕h2.
Thus edges partition into 1120 Steiner triples {h1,h2,h3}.
The cocycle g is constant on the 3 edges of each triple.

Triple counts:
- 520 triples with gauge weight 12
- 600 triples with gauge weight 16

Distinct gauge masks:
- 180 distinct 12-weight masks
- 600 distinct 16-weight masks

## E8 simple roots and Dynkin-edge gauge fixing
Using the E8 simple-root configuration derived earlier, each simple root has two signed preimages (genA/genB).
Brute force over 2^8 sign choices yields an assignment where all Dynkin-edge gauges are weight-12, and one edge gauge becomes 0.

See:
- dynkin_edge_cocycle_canonical_section.csv
- dynkin_edge_cocycle_optimized_signs.csv

## Files
- st_edges_root_graph_cocycle_3360.csv: cocycle on all edges (3360)
- st_triples_1120_cocycle.csv: Steiner triples and their cocycle (1120)
- gauge_masks_frequency_over_triples.csv: distinct gauge masks and counts
- im_neighbor_basis_points.json: 16-point basis of neighbor indicators spanning im(A)
