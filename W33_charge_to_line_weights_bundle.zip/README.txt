W33 charge (dF) projection to H^3 and 90-line weights

This bundle computes the tetrahedron 3-cochain J := dF from the quotient triangle holonomy field F,
then projects J into the 89D cohomology H^3 and further into the 90 non-isotropic line-weight model.

Outcome:
  - J=dF is nonzero on 3008 tetrahedra (flux distribution matches prior bundles),
  - but its H^3 class is trivial (all 89 coordinates are 0),
  - therefore its 90-line weights are also 0 (after gauge-normalization).

This is expected: any simplicial coboundary d(2-cochain) is exact and hence represents 0 in H^3.

Files:
  - dF_on_tetrahedra_9450.csv
  - dF_H3_coordinates_89.csv
  - dF_H3_coordinates_88.csv
  - dF_line_weights_90_normalized.csv
  - example_H3_basis0_line_weights_90_normalized.csv
  - report.json
