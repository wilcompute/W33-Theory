R operator (COO) mapping curved-triangle current y to 90-line aggregates via edge incidence.
