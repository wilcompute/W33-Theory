# W33: two canonical upgrades beyond the characteristic polynomial

## 1) Square-zero adjacency over GF(2)

For the SRG(40,12,2,4) adjacency matrix A, the SRG identity is:

A^2 = k I + λ A + μ(J - I - A)
    = 12 I + 2 A + 4(J - I - A)
    = 8 I - 2 A + 4 J.

Reducing mod 2 gives A^2 ≡ 0.

Consequences:
- im(A) ⊂ ker(A), so A is a differential d with d^2=0 on GF(2)^40.
- rank_GF2(A) = 16
- dim ker(A) = 24
- dim H := ker(A)/im(A) = 8.

This yields a canonically defined **8-dimensional quotient**.

## 2) PGSp(4,3) transitivity on core objects (hard orbit facts)

Using explicit GF(3)^4 generators:
- |PGSp(4,3)| = 51840
- points: one orbit of size 40, stabilizer 1296 (= 6^4)
- edges: one orbit of size 240, stabilizer 216 (= 6^3)
- minimal weight-6 kernel generators (line-pair XORs): one orbit of size 240, stabilizer 216
- incidence 8-cycles: one orbit of size 1620, stabilizer 32

These are the correct “primitive move sets” and “primitive loops” if you want a dynamics that is not just numerology.

