# Z3 curvature on the 40-vertex quotient and its non-exactness

## Setup
We have a 40-vertex quotient graph Q = complement(W33). Each vertex p carries a 3-element fiber tri(p).
Each quotient edge p-q carries a perfect matching (transport) between tri(p) and tri(q), giving an S3 permutation pi_pq.

For any triangle (p,q,r) (with p<q<r), the holonomy around the oriented cycle p-q-r-p is an element of A3 ~= Z3:
- identity -> 0
- (0 1 2) -> 1
- (0 2 1) -> 2

This defines a Z3-valued 2-cochain F on the 3240 triangles of Q.

## Orbit structure under Aut(W33)
Using the 10 generators of Aut(W33) (order 51840):
- edges of Q form a single orbit (size 540)
- triangles split into exactly two orbits:
  - size 360: F=0 (flat). These are exactly the triples lying on the 90 non-isotropic lines in PG(3,3): 90*C(4,3)=360.
  - size 2880: F is nonzero (F=1 or 2 depending on orientation).

## Non-exactness over Z3
Consider the simplicial 2-complex consisting of:
- vertices: 40
- edges: the 540 edges of Q
- faces: the 3240 triangles of Q

Let delta be the coboundary map delta: C^1(Q;Z3) -> C^2(Q;Z3).
Writing delta in coordinates gives a linear system A x = b over Z3 for delta(a) = F.

Computed ranks:
- rank(A) = 501
- rank([A|b]) = 502

Thus F is NOT in im(delta): there is no Z3 edge potential producing this curvature.
Equivalently, F represents a nontrivial cohomology class in C^2 / im(delta) for this 2-complex.
