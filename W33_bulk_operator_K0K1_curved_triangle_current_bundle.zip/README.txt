K0/K1 operators (COO) mapping tetra flux J to curved-triangle current y on the 2880 curved triangles.
