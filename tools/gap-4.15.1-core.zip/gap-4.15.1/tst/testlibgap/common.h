#include <stdio.h>
#include <unistd.h>

#include <libgap-api.h>
extern char ** environ;

void test_eval(const char * cmd);
