Holonomy / symplectic-phase decomposition artifacts

This bundle records the “holonomy vs. symplectic phase” computation on the 40-vertex quotient Q.

Key identities (all mod 3):
  - a(p,q) := <v_p, v_q> is a Z3 1-cochain on edges
  - Phi(p,q,r) = a(q,r) - a(p,r) + a(p,q) = δa is therefore exact (hence closed)
  - J := dF is, by definition, δ2(F), hence a 3-coboundary and cohomologically trivial in H^3

Files:
  - edge_symplectic_pairing_on_Q_edges_540.csv
  - tetra_coboundary_dF_dPhi_9450.csv
  - holonomy_phase_decomposition_report.json
  - H3_coordinates_of_dF.json
