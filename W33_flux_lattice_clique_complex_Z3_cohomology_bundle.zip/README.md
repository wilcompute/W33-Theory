# Flux lattice via Z3 cohomology of the clique complex of Q = complement(W33)

We consider the full clique complex (flag complex) of the 40-vertex quotient graph Q:
- C0: vertices (40)
- C1: edges (540)
- C2: triangles (3240)
- C3: tetrahedra K4 (9450)
- C4: K5 cliques (13824)
- C5: K6 cliques (10080)
- C6: K7 cliques (2880)
Max clique size is 7 (no K8).

Working over Z3, we compute coboundary ranks:
rank(delta0)=39, rank(delta1)=501, rank(delta2)=2739, rank(delta3)=6622, rank(delta4)=7201, rank(delta5)=2879.

This yields cohomology dimensions:
H0=1, H1=0, H2=0, H3=89, H4=1, H5=0, H6=1.

Interpretation:
- H2=0 means the Z3 curvature 2-cochain becomes cohomologically exact once we include K4 tetrahedra (the 2-skeleton obstruction disappears in the full clique complex).
- The first nontrivial "flux lattice" lives in H3 (dimension 89 over Z3), i.e. 89 independent Z3 3-cocycles modulo exact ones.
- There is a unique (1D) Z3 4-class and a unique top (6D) Z3 class.

Orbit structure under Aut(W33):
- Triangles split into 2 orbits: 360 flat and 2880 curved.
- Tetrahedra split into 3 orbits: 90 (exactly the 90 nonisotropic lines), 2880, 6480.
- K5: 2 orbits (5184, 8640)
- K6: 2 orbits (1440, 8640)
- K7: 1 orbit (2880)

We also compute the induced coboundary maps on orbit-constant (Aut-invariant) cochains, yielding a small invariant complex
with cohomology dims H0G=1, H1G=1, H2G=1, H3G=1, and higher invariant groups 0.

Files:
- clique_counts.json
- delta_ranks_Z3.json
- cohomology_dimensions_Z3.json
- tetra_orbits_flux.json
- invariant_complex_matrices.json
