#!/usr/bin/env python3
import numpy as np
import argparse
from pathlib import Path

def main():
    ap = argparse.ArgumentParser(description="Export 88x88 mod-3 generators from H3_generators_matrices_mod3.npz to GAP-readable .g file.")
    ap.add_argument("--npz", required=True, help="Path to H3_generators_matrices_mod3.npz")
    ap.add_argument("--out", required=True, help="Output .g file path")
    ap.add_argument("--use", choices=["generators", "generators_block"], default="generators_block",
                    help="Which array in the npz to export (default generators_block).")
    ap.add_argument("--dim", type=int, default=88, help="Dimension to export (default 88).")
    args = ap.parse_args()

    data = np.load(args.npz)
    G = data[args.use] % 3  # shape: (10, 89, 89)
    dim = args.dim
    G = G[:, :dim, :dim].astype(int)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    # GAP file: a list of integer matrices; GAP will wrap with GF(3) later.
    with out.open("w", encoding="utf-8") as f:
        f.write("# Auto-generated from %s\n" % args.npz)
        f.write("# Exported array: %s, dimension: %d\n" % (args.use, dim))
        f.write("W33gens := [\n")
        for gi, M in enumerate(G):
            f.write("  [\n")
            for row in M.tolist():
                f.write("    %s,\n" % row)
            f.write("  ]%s\n" % ("," if gi != len(G)-1 else ""))
        f.write("];\n")
        f.write("return W33gens;\n")

if __name__ == "__main__":
    main()
