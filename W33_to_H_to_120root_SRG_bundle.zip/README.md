# W33 → H (dim 8) → 120-root SRG(120,56,28,24)

## Step 1: GF(2) differential from SRG identity
For W33 = SRG(40,12,2,4), adjacency A satisfies:
  A^2 = 8I - 2A + 4J
so mod 2:
  A^2 ≡ 0.
Thus d := A is a differential on F2^40 and we define:
  H := ker(A)/im(A), with dim(H)=8.

## Step 2: 240 minimal generators project to 120 "projective roots"
The 240 weight-6 codewords given by XOR of two GQ lines through a point lie in ker(A).
Projecting each to H gives:
- 120 distinct nonzero H-elements
- each occurs exactly twice (240 = 2×120)
- every image element satisfies q=1 (nonsingular class)

## Step 3: The induced 120-vertex SRG
Using the quadratic form q on H, define bilinear form:
  b(x,y)=q(x+y)+q(x)+q(y).

On the 120 roots, define adjacency by b(x,y)=1.
This yields a strongly regular graph:
  SRG(120, 56, 28, 24)
with 3360 edges.

Complement graph has:
  SRG(120, 63, 30, 34).

Files:
- roots_120_list.csv
- generator_to_root_map.csv
- root_graph_edges_srg120_56_28_24.csv
- root_graph_adjacency_120x120.csv

