# Explicit basis for H^3 over Z3 (dimension 89)

We work on the clique (flag) complex of the 40-vertex quotient graph Q = complement(W33).

Cochains over Z3:
- C^2 is supported on triangles (3240)
- C^3 is supported on tetrahedra K4 (9450)
- C^4 is supported on K5 cliques (13824)

Coboundaries:
- delta2: C^2 -> C^3 has rank 2739
- delta3: C^3 -> C^4 has rank 6622

Therefore:
  dim H^3 = dim ker(delta3) - dim im(delta2) = (9450-6622) - 2739 = 89.

## Construction of the basis
1) Compute an echelon pivot representation of delta3 to obtain:
   - pivot tetra indices (6622)
   - free tetra indices (2828) parameterizing ker(delta3)

2) Restrict delta2 to the free tetra coordinates to get a map:
     delta2_free: C^2 (3240) -> F (2828),
   where F is the free-coordinate space.

3) Compute the image pivots of delta2_free. The nonpivot coordinates have cardinality 89 and give a canonical set of quotient coordinates.

4) For each of these 89 nonpivot free coordinates, set that free tetra variable to 1 and solve delta3 x=0 by back-substitution.
   The result is a 3-cocycle in ker(delta3) whose class is nontrivial modulo im(delta2).

Files:
- H3_basis_vectors_89_sparse.json: the 89 basis cocycles as sparse tetra-cochains
- H3_basis_meta_89.csv: summary of basis elements (free tetra, support size)
- tetra_index_map_9450.csv: mapping of tetra indices to 4-vertex cliques
- kernel_delta3_pivot_columns.json: pivot/free tetra index sets for ker(delta3)
- image_delta2_free_pivots.json: pivot/nonpivot free positions determining the 89-dimensional quotient basis

