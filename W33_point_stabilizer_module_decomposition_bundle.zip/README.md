# Point-stabilizer module decompositions (stabilizing point 0)

We work with W33 = SRG(40,12,2,4). Over GF(2), A^2=0, so define H := ker(A)/im(A), dim(H)=8.

Let G = Aut(W33) ≅ PGSp(4,3), |G|=51840. Let G_0 be the stabilizer of point 0, |G_0| = 1296.

## H module under G_0
Under the induced action on H, we find a direct sum decomposition:
  H ≅ W6 ⊕ V2,
where:
- dim(W6)=6 and the action on W6 has full order 1296 (faithful).
- dim(V2)=2 and the induced image group on V2 has order 6, i.e. GL(2,2) ≅ S3.

## im(A) module under G_0
The 16D image subspace im(A) decomposes under G_0 as:
  im(A) ≅ U2 ⊕ U6 ⊕ U8
with:
- U2 fixed pointwise (dimension 2).
  One basis vector is the indicator of the 12 neighbors of point 0 in W33;
  the other is its complement (including point 0), of size 28.
- dim(U6)=6 (faithful action, order 1296)
- dim(U8)=8 (image group order 432; kernel size 3).

See JSON files for explicit bases (in coordinates and as 40-point supports) and the block-basis generators.

