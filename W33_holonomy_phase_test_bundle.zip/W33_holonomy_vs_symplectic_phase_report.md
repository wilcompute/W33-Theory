# Holonomy vs symplectic triangle phase (2-qutrit test)

We compare the computed Z3 triangle holonomy `F(p,q,r)` on the 40-vertex quotient Q with the symplectic triangle phase

$$\Phi(p,q,r)=\langle v_p,v_q\rangle+\langle v_q,v_r\rangle+\langle v_r,v_p\rangle\pmod 3,$$

where `v_p` are the explicit GF(3)^4 projective representatives from the symplectic audit bundle and `⟨·,·⟩` is the same symplectic form J used in the W33 construction.


## Summary of outcomes

- Triangles: 3240

- Holonomy distribution F: {2: 1448, 1: 1432, 0: 360}

- Symplectic phase distribution Phi (using canonical reps): {1: 1248, 2: 1182, 0: 810}

- Residual D=F-Phi distribution: {0: 1662, 1: 802, 2: 776}


### Critical structural finding

Let `d` denote the simplicial coboundary on the clique complex of Q, so for each tetrahedron (a<b<c<d):

$$ (dG)(a,b,c,d)=G(b,c,d)-G(a,c,d)+G(a,b,d)-G(a,b,c)\pmod 3.$$


- `d(Phi)=0` on all 9450 tetrahedra (Phi is a Z3 2-cocycle / background flat 2-form).

- `d(F)` has distribution {0: 6442, 2: 1496, 1: 1512} with 3008 nonzero-flux tetrahedra (the charge sources).

Therefore holonomy `F` is **not** purely the symplectic commutator 2-form. Instead:

- `Phi` behaves exactly like a background commutator/area phase (closed 2-form).

- `F` is the physical field strength with sources; its 3-coboundary encodes charge.


This is precisely the discrete gauge-theory pattern: a closed background 2-form plus a sourced curvature field.
