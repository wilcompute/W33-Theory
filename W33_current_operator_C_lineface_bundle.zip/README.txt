C_lineface operator (COO) and resulting m_line = C_lineface * J (plus sum=0 gauge-fix).
