Permutation module comparison (GAP + MeatAxe)

Files:
- gens40.g: 10 generators as permutations on 40 points (Aut(W33), size 51840)
- noniso_lines90.g: the 90 non-isotropic lines as 4-subsets of {1..40}
- w33_perm_module_check.g: builds action on 90 lines, constructs the 90D permutation module over GF(3),
  then constructs the 89D augmentation submodule, and prints irreducibility + endomorphism ring size.

Run:
  gap -q w33_perm_module_check.g

Goal:
Compare the 89D augmentation module on 90 nonisotropic lines to the 89D H^3 module.
