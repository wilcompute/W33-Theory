Extra GAP/MeatAxe diagnostics

This zip adds w33_meataxe_extra.g which checks both the 88D and full 89D modules.

Steps:
1) Unzip W33_meataxe_and_sage_certification_scripts.zip in the same directory.
2) Generate gens89.g and gens88.g:
   python3 export_generators_to_gap.py --npz H3_generators_matrices_mod3.npz --out gens89.g --use generators_block --dim 89
   python3 export_generators_to_gap.py --npz H3_generators_matrices_mod3.npz --out gens88.g --use generators_block --dim 88
3) Run:
   gap -q w33_meataxe_extra.g

Interpretation:
- If IsIrreducible(88)=true and EndRingSize(88)=3, then centralizer dimension is 1 (scalars over GF(3)).
- If EndRingSize(88)=3^d (d>1) with irreducible true, then endomorphism ring is a field extension GF(3^d).
- The split test for 89D is heuristic; use composition factors if available.
