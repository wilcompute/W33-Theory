# Minimal Z3 flux cycles in the quotient: tetrahedron boundaries

## Context
On the 40-vertex quotient Q = complement(W33), we have a Z3-valued curvature 2-cochain F on the 3240 triangles.

Although F is not a coboundary (no Z3 edge potential produces it), we can exhibit explicit 2-cycles with nonzero total flux.

## The key observation
Any 4-clique (tetrahedron) {a<b<c<d} in Q has a simplicial boundary consisting of 4 triangles:
  (a,b,c), (a,b,d), (a,c,d), (b,c,d)

As a 2-chain over Z3, the oriented boundary is:
  (b,c,d) - (a,c,d) + (a,b,d) - (a,b,c)   mod 3

This 2-chain has zero edge boundary (it is a 2-cycle), and its total curvature flux is:
  dF(a,b,c,d) = F(b,c,d) - F(a,c,d) + F(a,b,d) - F(a,b,c)   mod 3

## Results
There are 9450 tetrahedra (4-cliques) in Q. Their flux distribution is:
- flux 0: 6442
- flux 1: 1512
- flux 2: 1496

Therefore there are 3008 explicit *minimal-support* flux cycles (support size 4 triangles) witnessing nontrivial Z3 flux.

Special flat case:
- 90 tetrahedra have all 4 faces flat (F=0). These correspond to the 90 non-isotropic projective lines (4 points on a line), hence flux 0.

Files:
- tetrahedra_flux_nonzero_3008.csv: all nonzero-flux tetrahedra and their face F values
- example_flux_cycles.json: two worked examples (flux 1 and flux 2) with explicit boundary coefficients
