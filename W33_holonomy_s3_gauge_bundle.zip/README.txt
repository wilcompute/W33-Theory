W33 holonomy as an S3/Z2 local-coefficient cocycle (gauge bundle)

This bundle derives an S3 transport interpretation of the quotient triangle holonomy field F on Q.

Computed facts:
  - Each quotient edge has a canonical transport bijection between 3-element fibers, giving an S3 permutation.
  - The parity s(p,q)∈Z2 is a 1-cocycle (ds=0) and is exact (s=dt for an explicit vertex function t).
  - The transported coboundary d_sF is identically zero on all 9450 tetrahedra (a discrete Bianchi identity).
  - After the gauge adjustment F^(t)(p,q,r)=(-1)^{t(p)}F(p,q,r), the untwisted coboundary dF^(t) vanishes,
    and there exists an explicit edge potential A with dA = F^(t).

Files:
  - edge_transport_permutations_540.csv
  - vertex_gauge_t_40.csv
  - triangle_holonomy_F_3240.csv
  - triangle_holonomy_F_t_3240.csv
  - edge_potential_A_540.csv
  - report.json
