# Aut(W33) action on H^3 over Z3 (explicit 89D representation)

This bundle provides an explicit linear representation of the 40-point automorphism generators (order 51840 group) on:

  H^3( CliqueComplex(Q); Z3 )

where Q is the 40-vertex quotient graph (complement of W33).

## What is included
- H3_generators_matrices_mod3.npz:
  - generators: 10 x 89 x 89 matrices over Z3 (entries 0,1,2)
  - generators_block: same matrices conjugated into a block upper-triangular form (88 + 1 decomposition)

- block_basis_change_matrices_mod3.npz:
  - Bcols: change-of-basis matrix (columns are new basis vectors in the original 89-basis)
  - Bcols_inv: inverse matrix

- submodule_basis_88x89.csv:
  A basis (rows) for an invariant 88D submodule in the 89D module.

- quotient_functional_w.csv:
  A nonzero linear functional w (in the dual module) whose kernel is exactly the 88D submodule.
  Under the action, w transforms by a 1D character (see analysis.json).

## Key findings (computed)
- The full 89D module has fixed-space dimension 0 (no nonzero invariant vectors).
- There is an invariant 88D submodule. The quotient is 1D, with the similitude generator (index 9) acting by 2 (-1 mod 3),
  and the other 9 generators acting by 1.
- Restricted to the 88D submodule, the fixed space is also 0.
- Random submodule generation tests suggest the 88D submodule is irreducible over Z3 (heuristic).

