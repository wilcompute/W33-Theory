# H = ker(A)/im(A) for W33 over GF(2): an 8D orthogonal geometry

Define A as the 40×40 adjacency matrix of the W33 point graph (SRG(40,12,2,4)).

Because the SRG identity gives A^2 = 8I - 2A + 4J, we have A^2 ≡ 0 (mod 2).
So d := A is a differential on F2^40 with d^2=0, and im(d) ⊂ ker(d).

Homology:
  H := ker(A)/im(A)

Computed dimensions:
- dim im(A) = 16
- dim ker(A) = 24
- dim H = 8

## Induced symmetry
The full PGSp(4,3) automorphism group (order 51840) acts on points, hence on F2^40 by coordinate permutations,
preserving A and inducing an action on H.

In our chosen basis, the induced subgroup of GL(8,2) has order:
  |G_H| = 51840

## Invariant quadratic form
The induced action preserves a nontrivial quadratic polynomial q: F2^8 → F2.
In the chosen coordinates x0..x7, one invariant is:

  q(x) = x0 + x1 + x2 + x5 + x6 + x7 + x0x1 + x0x4 + x0x6 + x1x3 + x1x7 + x2x5 + x2x6 + x2x7 + x3x4 + x3x5 + x4x5 + x4x7 + x5x6 + x5x7   (mod 2)

Counts:
- q=0 on 136 vectors (including 0), q=1 on 120 vectors.
- On nonzero vectors: 135 with q=0 and 120 with q=1.
- The group action has exactly two nonzero orbits of those sizes.

This is the signature split of an orthogonal (quadratic-form) geometry over F2 on H.

