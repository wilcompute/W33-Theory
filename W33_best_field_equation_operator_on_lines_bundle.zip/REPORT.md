# Best Aut(W33)-equivariant linear predictor on 90-line vacuum sector

We work on the 90 non-isotropic lines, with two observed line vectors (mod 3), mapped to real values in {-1,0,1} by 2 -> -1 and mean-removed:
- z: bulk-to-vacuum shadow (R*y)
- m: boundary moment (C_lineface*J) projected to sum=0 mod 3

Because the Aut(W33) commutant on 90 lines has 5 joint modes (simultaneous eigenspaces of S and Ameet),
the most general Aut-equivariant linear filter is diagonal by mode. The best least-squares map m_hat = D z uses one scalar alpha_k per mode.

## Achieved fit
R^2 (energy explained): 0.081674  (~8.17%)

This confirms m and z are largely independent excitations in the same 88D sector; no Aut-invariant linear map can strongly predict one from the other.

## Mode scalars (alpha)
See mode_scalars_alpha.csv.

## Closed-form "field equation operator"
Let:
- S be the canonical involution pairing (45 transpositions).
- A be the meet adjacency on lines (32-regular).
Then the best modewise filter equals the polynomial:

D = c0 I + c1 S + c2 A + c3 A^2 + c4 S A

Coefficients:
c0 = -0.165564340879
c1 = 0.212651575947
c2 = -0.045459215132
c3 = 0.002176660238
c4 = -0.025665388584

We verified numerically that this polynomial representation matches the projector-built D to machine precision.

Files:
- best_modewise_operator_coeffs.csv
- mode_scalars_alpha.csv
- best_modewise_operator_m_from_z.npz
