# Quotient closure result: 240 → 120 → (collapse) 40 = complement(W33)

We start from the globally gauge-fixed signed lift on the 120-root graph (no 16-defects; only 0 and 12).

## Collapse rule
The 120 roots partition into 40 disjoint triples, one for each original W33 point p.
These are exactly the 40 flat (0-defect) Steiner triples under the gauge-fixed lift.

Collapsing each triple to a meta-vertex labeled by p produces a 40-vertex quotient graph Q.

## Quotient adjacency
Between two base points p≠q, the number of 12-weight edges between tri(p) and tri(q) is either:
- 0  (no connection), or
- 6  (always exactly six).

Thus Q has an edge p~q iff multiplicity=6.

Computed result:
- Q is 27-regular on 40 vertices (540 edges),
- and Q equals the complement of the original W33 point graph (degree 27 = 39-12).

## Edge decoration: canonical 6-cycle
For every quotient edge p~q, the induced bipartite graph between the 3 roots in tri(p) and the 3 roots in tri(q)
has exactly 6 edges and is 2-regular on each side.
It is therefore K3,3 minus a perfect matching, i.e. a 6-cycle.

Equivalently, each quotient edge carries a canonical perfect matching (the missing 3 edges).

## Triangle holonomy in the quotient
For a quotient triangle (p,q,r), compose the three matchings around the triangle to get a permutation of tri(p).
Empirical result:
- 360 quotient triangles give identity holonomy,
- 2880 give a 3-cycle holonomy.

Classification:
- Identity holonomy triangles are exactly those (p,q,r) that lie on a non-isotropic projective line in PG(3,3).
There are 90 non-isotropic lines, and each line contributes C(4,3)=4 triples, yielding 360.

This identifies "flat curvature" precisely with the 90 non-isotropic line structure.

Files:
- quotient_graph_edges_540.csv
- quotient_graph_edge_decorations_matchings.csv
- quotient_triangles_holonomy_3240.csv

