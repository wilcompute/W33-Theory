Charge decomposition and line moments

This bundle records the nonzero support of J := dF on the 9450 quotient tetrahedra, and summarizes:
  - how charged tetrahedra split by flat-face-count orbit type (bulk/boundary/vacuum)
  - boundary attachments to the 90 non-isotropic lines (line moments)
  - pointwise charge incidence on the 40 quotient vertices

Files:
  - charged_tetrahedra_3008.csv
  - point_charge_incidence_40.csv
  - boundary_line_moment_m_90.csv
  - summary.json
